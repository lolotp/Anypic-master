#import <UIKit/UIKit.h>

@interface PAWWelcomeViewController : UIViewController

- (IBAction)loginButtonSelected:(id)sender;
- (IBAction)createButtonSelected:(id)sender;
- (IBAction)gotoParse:(id)sender;

@end
