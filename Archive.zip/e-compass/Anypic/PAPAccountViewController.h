#import "PAPPhotoTimelineViewController.h"

@interface PAPAccountViewController : PAPPhotoTimelineViewController

@property (nonatomic, strong) PFUser *user;

@end
