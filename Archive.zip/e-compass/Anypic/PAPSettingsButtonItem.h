@interface PAPSettingsButtonItem : UIBarButtonItem

- (id)initWithTarget:(id)target action:(SEL)action;

@end
