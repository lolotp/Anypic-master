import sys

for i in range(7):
	sys.stdin.readline()

for l in sys.stdin.readlines():
	print l.strip()
